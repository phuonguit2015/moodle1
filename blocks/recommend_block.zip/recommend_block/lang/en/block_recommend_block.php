<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'block_phuong_user', language 'en', branch 'MOODLE_20_STABLE'
 *
 * @package   block_phuong_user
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['configtimetosee'] = 'Number of minutes determining the period of inactivity after which a user is no longer considered to be online.';
$string['phuong_user:addinstance'] = 'Add a new recommend block';
$string['phuong_user:myaddinstance'] = 'Add a new recommend block to Dashboard';
$string['phuong_user:viewlist'] = 'View list of online users';
$string['periodnminutes'] = 'last {$a} minutes';
$string['pluginname'] = 'Recommend Blocks';
$string['timetosee'] = 'Remove after inactivity (minutes)';
